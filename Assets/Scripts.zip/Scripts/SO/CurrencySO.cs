using UnityEngine;

[CreateAssetMenu(fileName = "NewCurrency", menuName = "Items/Currency")]
public class CurrencySO : ItemSO
{
    public int amount;
}
