using UnityEngine;

public abstract class SkillSO : ScriptableObject
{
    public string skillName;
    public Sprite skillIcon;
    public int manaCost;
    public float cooldown;
    public string description;

    public abstract void Activate(GameObject user);
}
