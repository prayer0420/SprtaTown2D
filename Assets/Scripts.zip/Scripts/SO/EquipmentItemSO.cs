using UnityEngine;

public abstract class EquipmentItemSO : ItemSO
{
    public EquipmentType equipmentType;
    public int AttackBonus;
    public int DefenseBonus;
    public int healthBonus;
    public int manaBonus;
}
