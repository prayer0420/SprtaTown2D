using UnityEngine;
using UnityEngine.UI;

//����Ʈ �Ѱ�
public class QuestSlot : MonoBehaviour
{
    public Text questNameText;
    public Text questDescriptionText;
    public Slider progressBar;

    private QuestSO quest;

    public void SetQuest(QuestSO newQuest)
    {
        quest = newQuest;
        questNameText.text = quest.questName;
        questDescriptionText.text = quest.description;

        UpdateProgress();
    }

    private void Update()
    {
        UpdateProgress();
    }

    private void UpdateProgress()
    {
        if (quest != null && quest.objective != null)
        {
            float progress = (float)quest.objective.currentCount / quest.objective.targetCount;
            progressBar.value = progress;
        }
    }
}
