using UnityEngine;
using UnityEngine.UI;

public class SkillSlot : MonoBehaviour
{
    public Image skillIcon;
    public Text skillNameText;
    public Button skillButton;

    private SkillSO skill;

    public void SetSkill(SkillSO newSkill)
    {
        skill = newSkill;
        skillIcon.sprite = skill.skillIcon;
        skillNameText.text = skill.skillName;

        // ��ų ��ư Ŭ�� �̺�Ʈ ���
        skillButton.onClick.AddListener(OnSkillButtonClicked);
    }

    private void OnSkillButtonClicked()
    {
        // ��ų ���
        GameManager.Instance.Player.skillSystem.UseSkill(skill);
    }
}
