using System;
using System.Collections.Generic;
using UnityEngine;

public class SkillSystem
{
    public List<SkillSO> learnedSkills = new List<SkillSO>();
    private Dictionary<SkillSO, float> skillCooldowns = new Dictionary<SkillSO, float>();

    // �̺�Ʈ ����
    public event Action OnSkillChanged;

    public void LearnSkill(SkillSO skill)
    {
        if (!learnedSkills.Contains(skill))
        {
            learnedSkills.Add(skill);
            OnSkillChanged?.Invoke();
            Debug.Log($"{skill.skillName} ��ų�� ������ϴ�.");
        }
    }

    public void UseSkill(SkillSO skill)
    {
        if (learnedSkills.Contains(skill))
        {
            if (GameManager.Instance.Player.statHandler.currentMana >= skill.manaCost)
            {
                if (skillCooldowns[skill] <= 0f)
                {
                    GameManager.Instance.Player.statHandler.currentMana -= skill.manaCost;
                    skill.Activate(GameManager.Instance.Player.gameObject);
                    skillCooldowns[skill] = skill.cooldown;
                    Debug.Log($"{skill.skillName} ��ų�� ����߽��ϴ�.");
                }
                else
                {
                    Debug.Log("��ų�� ��ٿ� ���Դϴ�.");
                }
            }
            else
            {
                Debug.Log("������ �����մϴ�.");
            }
        }
    }

    public void UpdateSkillCooldowns()
    {
        List<SkillSO> keys = new List<SkillSO>(skillCooldowns.Keys);
        foreach (var skill in keys)
        {
            if (skillCooldowns[skill] > 0f)
            {
                skillCooldowns[skill] -= Time.deltaTime;
            }
        }
    }
}
