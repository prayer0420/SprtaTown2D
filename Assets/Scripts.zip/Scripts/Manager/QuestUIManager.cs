﻿using UnityEngine;

public class QuestUIManager : MonoBehaviour
{
    public static QuestUIManager Instance;

    public GameObject questListUIPrefab; // 퀘스트 목록 UI 프리팹
    private GameObject questListUIInstance;

    private void Awake()
    {
        Instance = this;
    }

    // 퀘스트 목록 표시
    public void ShowQuestList(NPCDataSO npcData)
    {
        if (questListUIInstance == null)
        {
            //퀘스트 목록 UI프리팹 만들기
            questListUIInstance = Instantiate(questListUIPrefab, transform);
        }
        //퀘스트 목록 UI 활성화
        questListUIInstance.SetActive(true);

        // 퀘스트 목록 업데이트
        QuestListUI questListUI = questListUIInstance.GetComponent<QuestListUI>();
        questListUI.UpdateQuestList(npcData);
    }

    // 퀘스트 목록 숨기기
    public void HideQuestList()
    {
        if (questListUIInstance != null)
        {
            questListUIInstance.SetActive(false);
        }
    }
}
