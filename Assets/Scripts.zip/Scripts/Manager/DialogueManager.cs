using UnityEngine;
using System.Collections.Generic;

public class DialogueManager : MonoBehaviour
{
    public static DialogueManager Instance;

    public DialogueUI dialogueUI;
    public bool IsDialogueActive { get; private set; } = false;

    private Queue<string> sentences; // ��� ť

    private void Awake()
    {
        // �̱��� ���� ����
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(this);
        }

        sentences = new Queue<string>();
    }

    // ��ȭ ����
    public void StartDialogue(DialogueSO dialogue)
    {
        IsDialogueActive = true;

        sentences.Clear();

        // ��� ť�� ��� �߰�
        foreach (var line in dialogue.dialogueLines)
        {
            sentences.Enqueue(line.dialogueText);
        }

        dialogueUI.ShowDialogue();
        DisplayNextSentence();
    }

    // ���� ���� ǥ��
    public void DisplayNextSentence()
    {
        if (sentences.Count == 0)
        {
            EndDialogue();
            return;
        }

        string sentence = sentences.Dequeue();
        dialogueUI.DisplaySentence(sentence);
    }

    // ��ȭ ����
    public void EndDialogue()
    {
        dialogueUI.HideDialogue();
        IsDialogueActive = false;
    }
}
