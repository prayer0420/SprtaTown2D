using UnityEngine;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    public InventoryUI inventoryUI;
    public StatusUI statusUI;
    public SkillUI skillUI;
    public QuestUI questUI;
    public DialogueUI dialogueUI;
    public UserUI userUI;

    private void Awake()
    {
        // �̱��� ���� ����
        if (Instance == null)
        {
            Instance = this;
            // �� ��ȯ �ÿ��� ����
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        // �÷��̾��� �̺�Ʈ�� �����Ͽ� UI ������Ʈ�� �̺�Ʈ ������� ó��
        if (GameManager.Instance.Player != null)
        {
            GameManager.Instance.Player.OnStatusChanged += UpdateStatusUI;
            GameManager.Instance.Player.OnExperienceGained += UpdateStatusUI;
            GameManager.Instance.Player.inventorySystem.OnInventoryChanged += UpdateInventoryUI;
            GameManager.Instance.Player.skillSystem.OnSkillChanged += UpdateSkillUI;
            QuestManager.Instance.OnQuestUpdated += UpdateQuestUI;
        }

        // �ʱ� UI ������Ʈ
        UpdateAllUI();
    }

    // ��� UI ������Ʈ �Լ�
    public void UpdateAllUI()
    {
        UpdateInventoryUI();
        UpdateStatusUI();
        UpdateSkillUI();
        UpdateQuestUI();
        UpdateUserUI();
    }

    private void Update()
    {
        UpdateAllUI();
    }

    // ���� UI ������Ʈ �Լ���
    public void UpdateInventoryUI()
    {
        if (inventoryUI != null)
        {
            inventoryUI.UpdateInventoryUI();
        }
    }

    public void UpdateStatusUI()
    {
        if (statusUI != null)
        {
            statusUI.UpdateStatusUI();
        }
    }

    public void UpdateSkillUI()
    {
        if (skillUI != null)
        {
            skillUI.UpdateSkillUI();
        }
    }

    public void UpdateQuestUI()
    {
        if (questUI != null)
        {
            questUI.UpdateQuestUI();
        }
    }

    public void ShowDialogueUI(DialogueSO dialogue)
    {
        if (DialogueManager.Instance != null)
        {
            DialogueManager.Instance.StartDialogue(dialogue);
        }
    }

    public void HideDialogueUI()
    {
        if (DialogueManager.Instance != null)
        {
            DialogueManager.Instance.EndDialogue();
        }
    }

    public void UpdateUserUI()
    {
        if (userUI != null)
        {
            userUI.UpdateUserList();
        }
    }
}
