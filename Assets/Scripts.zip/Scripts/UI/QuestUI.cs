using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

//Q������ ��Ÿ���� Questâ(UI)
public class QuestUI : MonoBehaviour
{
    public Toggle activeQuestsToggle;
    public Toggle completedQuestsToggle;
    public Transform questListContent;
    public GameObject questSlotPrefab;

    private void Start()
    {
        activeQuestsToggle.onValueChanged.AddListener((isOn) => UpdateQuestUI());
        completedQuestsToggle.onValueChanged.AddListener((isOn) => UpdateQuestUI());
        gameObject.SetActive(false);
    }

    private void Update()
    {
        // Q Ű�� ����Ʈ UI ���
        if (Input.GetKeyDown(KeyCode.Q))
        {
            gameObject.SetActive(!gameObject.activeSelf);
            if (gameObject.activeSelf)
            {
                UpdateQuestUI();
            }
        }
    }

    // ����Ʈ UI ������Ʈ
    public void UpdateQuestUI()
    {
        // ���� ���� ����
        foreach (Transform child in questListContent)
        {
            Destroy(child.gameObject);
        }

        List<QuestSO> questsToDisplay = new List<QuestSO>();

        if (activeQuestsToggle.isOn)
        {
            questsToDisplay.AddRange(QuestManager.Instance.activeQuests);
        }

        if (completedQuestsToggle.isOn)
        {
            questsToDisplay.AddRange(QuestManager.Instance.completedQuests);
        }

        foreach (var quest in questsToDisplay)
        {
            GameObject questSlotObj = Instantiate(questSlotPrefab, questListContent);
            QuestSlot questSlot = questSlotObj.GetComponent<QuestSlot>();
            questSlot.SetQuest(quest);
        }
    }
}
