﻿using UnityEngine;
using UnityEngine.UI;

public class QuestAcceptanceUI : MonoBehaviour
{
    public Text questNameText;
    public Text questDescriptionText;
    public Button acceptButton;
    public Button declineButton;

    private QuestSO currentQuest;

    private void Start()
    {
        acceptButton.onClick.AddListener(() => AcceptQuest());
        declineButton.onClick.AddListener(() => DeclineQuest());
    }

    // 퀘스트 수락/거절 UI 표시
    public void Show(QuestSO quest)
    {
        currentQuest = quest;
        questNameText.text = quest.questName;
        questDescriptionText.text = quest.description;

        gameObject.SetActive(true);
    }

    // UI 숨기기
    public void Hide()
    {
        gameObject.SetActive(false);
    }

    // 퀘스트 수락
    private void AcceptQuest()
    {
        QuestManager.Instance.AcceptQuest(currentQuest);
        Hide();
        ShowMessage("퀘스트를 수락했습니다.");
        QuestUIManager.Instance.HideQuestList();
    }

    // 퀘스트 거절
    private void DeclineQuest()
    {
        Hide();
        ShowMessage("퀘스트를 거절했습니다.");
    }

    // 메시지 표시
    private void ShowMessage(string message)
    {
        // 메시지를 화면에 표시합니다.
        Debug.Log(message);
    }
}
