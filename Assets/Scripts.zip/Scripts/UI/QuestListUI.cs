﻿using UnityEngine;
using UnityEngine.UI;

//퀘스트리스트들을 모아놓은 UI
public class QuestListUI : MonoBehaviour
{
    public Transform questButtonContainer;
    public GameObject questButtonPrefab;
    public Button backButton;

    private NPCDataSO currentNPCData;

    private void Start()
    {
        backButton.onClick.AddListener(() => QuestUIManager.Instance.HideQuestList());
    }

    // 퀘스트 목록 업데이트
    public void UpdateQuestList(NPCDataSO npcData)
    {
        currentNPCData = npcData;

        // 기존 버튼 제거
        foreach (Transform child in questButtonContainer)
        {
            Destroy(child.gameObject);
        }

        // 퀘스트 버튼 생성
        for (int i = 0; i < npcData.quests.Length; i++)
        {
            CreateQuestButton(npcData.quests[i], i);
        }
    }

    // 퀘스트 버튼 생성
    private void CreateQuestButton(QuestSO quest, int questIndex)
    {
        GameObject questButtonObj = Instantiate(questButtonPrefab, questButtonContainer);
        Button questButton = questButtonObj.GetComponent<Button>();
        Text questButtonText = questButton.GetComponentInChildren<Text>();
        questButtonText.text = quest.questName;

        questButton.onClick.AddListener(() => OnQuestButtonClicked(quest, questIndex));
    }

    // 퀘스트 버튼 클릭 시 처리
    private void OnQuestButtonClicked(QuestSO quest, int questIndex)
    {
        // 선행 퀘스트 완료 여부 확인
        if (questIndex > 0)
        {
            QuestSO previousQuest = currentNPCData.quests[questIndex - 1];
            if (!QuestManager.Instance.IsQuestCompleted(previousQuest))
            {
                // 선행 퀘스트 미완료 시 메시지 표시
                ShowMessage("퀘스트를 진행할 수 없습니다. 선행 퀘스트를 완료해주세요.");
                return;
            }
        }

        // 퀘스트 수락/거절 UI 표시
        QuestAcceptanceUI questAcceptanceUI = FindObjectOfType<QuestAcceptanceUI>();
        questAcceptanceUI.Show(quest);
    }

    // 메시지 표시
    private void ShowMessage(string message)
    {
        // 메시지를 화면에 표시합니다.
        Debug.Log(message);
    }
}
