using UnityEngine;
using UnityEngine.UI;

public class SkillUI : MonoBehaviour
{
    public GameObject skillPanel;
    public Transform skillSlotContainer;
    public GameObject skillSlotPrefab;

    private SkillSystem skillSystem;

    private void Start()
    {
        skillSystem = GameManager.Instance.Player.skillSystem;
        UpdateSkillUI();
    }

    public void UpdateSkillUI()
    {
        // ���� ��ų ���� ����
        foreach (Transform child in skillSlotContainer)
        {
            Destroy(child.gameObject);
        }

        // ��ų ǥ��
        foreach (var skill in skillSystem.learnedSkills)
        {
            GameObject skillSlotObj = Instantiate(skillSlotPrefab, skillSlotContainer);
            SkillSlot skillSlot = skillSlotObj.GetComponent<SkillSlot>();
            skillSlot.SetSkill(skill);
        }
    }
}
