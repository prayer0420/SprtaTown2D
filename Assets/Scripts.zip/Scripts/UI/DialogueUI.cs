using UnityEngine;
using UnityEngine.UI;

public class DialogueUI : MonoBehaviour
{
    public GameObject dialoguePanel;
    public Text dialogueText;

    private void Start()
    {
        HideDialogue();
    }

    // ��ȭ UI ǥ��
    public void ShowDialogue()
    {
        dialoguePanel.SetActive(true);
    }

    // ��ȭ UI �����
    public void HideDialogue()
    {
        dialoguePanel.SetActive(false);
    }

    // ���� ǥ��
    public void DisplaySentence(string sentence)
    {
        dialogueText.text = sentence;
    }

    private void Update()
    {
        // Space Ű�� ���� �������� �Ѿ��
        if (dialoguePanel.activeSelf && Input.GetKeyDown(KeyCode.Space))
        {
            DialogueManager.Instance.DisplayNextSentence();
        }
    }
}
